import React from "react"
import MonetizationForm from "../Form/Monetization"

class Monetization extends React.Component{
    
    render(){
        return <MonetizationForm {...this.props} />
    }

}

export default Monetization