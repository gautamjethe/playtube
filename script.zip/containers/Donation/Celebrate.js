import React from "react"
import css from "./celebrate.css"

const Index = (props) => {
    return (
        <div className="pyro">
            <div className="before"></div>
            <div className="after"></div>
        </div>
    )
}

export default Index;